function mainUpdate(type) {
	document.getElementById('left_top').addEventListener('touchstart', () => {
		$('#covid_title').text("...تحميل");
		$('#covid_cases').text("...تحميل");
		$('#covid_deaths').text("...تحميل.");
		$('#covid_recoveries').text("...تحميل");
		init_main();
	});
}
console.log('[HSWB] !تمت تهيئة وظائف XenInfo');
