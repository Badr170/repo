window.addEventListener("load", function() {

	document.body.style.width = '100%';
	document.body.style.height = '100%';
	console.log('[HSWB]!تم تحميل الأداة بنجاح');

}, false);

function update_data() {
	$('#covid_title').text("...جار التحميل");
	console.log('[COVID-19]..تحديث البيانات');

	let covidUrl = 'https://corona.lmao.ninja';
	switch(locationType) {
		case 'province':
			$.getJSON(covidUrl + '/v2/jhucsse', (data) => {
				let countryData = data.find((elem) => { return elem.province === province; });
				$('#covid_title').text("حاله كورونا" + countryData.province);
				$('#covid_cases').text(countryData.stats.confirmed);
				$('#covid_deaths').text(countryData.stats.deaths);
				$('#covid_recoveries').text(countryData.stats.recovered);
			});
			break;
		case 'بلد':
			$.getJSON(covidUrl + '/v2/بلدان', (data) => {
				let countryData = data.find((elem) => { return elem.country === country; });
				$('#covid_title').text("حاله كورونا" + countryData.country);
				$('#covid_cases').text(countryData.cases);
				$('#covid_deaths').text(countryData.deaths);
				$('#covid_recoveries').text(countryData.recovered);
			});
			break;
	}
	return;
}

function init_main() {
	// document.styleSheets[0].href = '';
	$('head').append('<link rel="ورقة الأنماط" href="assets/style_' + colorScheme + '.css" type="text/css" />');
	setTimeout(() => {
		update_data();
	}, 1000);
	setInterval(() => {
		update_data();
	}, 1000 * refreshRate);
	console.log('[HSWB] !تمت تهيئة الإعدادات');
}

init_main();
