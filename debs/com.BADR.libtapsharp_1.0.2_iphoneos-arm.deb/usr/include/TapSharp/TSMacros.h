// ---------------------------------------------------------------------------------------------------------------------
// Checks for device system version compatibility
// ---------------------------------------------------------------------------------------------------------------------

#ifndef SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v) ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#endif


// ---------------------------------------------------------------------------------------------------------------------
// Paths and Bundle!
// ---------------------------------------------------------------------------------------------------------------------

#ifndef kTSCommonBundlePath
#define kTSCommonBundlePath @"/Library/Application Support/libtapsharp"
#endif


// ---------------------------------------------------------------------------------------------------------------------
// Colors
// ---------------------------------------------------------------------------------------------------------------------

#ifndef UIColorFromRGBA
#define UIColorFromRGBA(r, g, b, a) [UIColor colorWithRed:(float)r/255.0f green:(float)g/255.0f blue:(float)b/255.0f alpha:(float)a]
#endif

#ifdef UIColorFromRGB
#define UIColorFromRGB(r, g, b) UIColorFromRGBA(r, g, b, 1.0f)
#endif
