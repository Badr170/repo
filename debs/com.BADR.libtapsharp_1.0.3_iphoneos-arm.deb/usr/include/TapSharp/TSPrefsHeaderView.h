#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface TSPrefsHeaderView : UIView
@property(nonatomic, retain) UIView *shadeView;
@property(nonatomic, retain) UIImageView *iconView;
@property(nonatomic, retain) UIView *containerView;
@property(nonatomic, retain) UIView *backgroundImageView;
@property(nonatomic, retain) UIView *titleView;
@property(nonatomic, retain) UILabel *titleLabel;
@property(nonatomic, retain) UILabel *subtitleLabel;
+(instancetype)headerWithTitle:(NSString *)title subtitle:(NSString *)subtitle icon:(UIImage *)icon background:(UIImage *)image;
-(instancetype)initWithTitle:(NSString *)title subtitle:(NSString *)subtitle icon:(UIImage *)icon background:(UIImage *)image;
-(UIView *)createBackgroundImageView:(UIImage *)image;
@end
