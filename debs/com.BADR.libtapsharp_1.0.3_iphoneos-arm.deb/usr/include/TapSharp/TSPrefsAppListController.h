#import "TSPrefsBaseListController.h"

@interface TSPrefsAppListController : TSPrefsBaseListController {
    NSArray* _supportedApplications;
}
-(NSArray*)applicationNames;
-(NSArray*)bundleIdentifiers;
-(NSArray*)supportedApplications;
-(NSArray *)excludedApplications;
-(NSArray *)excludedBundleIdentifiers;
@end
