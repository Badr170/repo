// ---------------------------------------------------------------------------------------------------------------------
// Checks for device system version compatibility
// ---------------------------------------------------------------------------------------------------------------------

#ifndef kCFCoreFoundationVersionNumber_iOS_13_0
#define kCFCoreFoundationVersionNumber_iOS_13_0 1665.15
#endif

#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v) ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)


// ---------------------------------------------------------------------------------------------------------------------
// Paths and Bundle!
// ---------------------------------------------------------------------------------------------------------------------

#define kTSCommonBundlePath @"/Library/Application Support/libtapsharp"


// ---------------------------------------------------------------------------------------------------------------------
// Macro Functions
// ---------------------------------------------------------------------------------------------------------------------

#define UIColorFromRGBA(r, g, b, a) [UIColor colorWithRed:(float)r/255.0f green:(float)g/255.0f blue:(float)b/255.0f alpha:(float)a]
#define UIColorFromRGB(r, g, b) UIColorFromRGBA(r, g, b, 1.0f)

#ifndef LOCALIZE
#define LOCALIZE(key, table, bundle, comment) NSLocalizedStringFromTableInBundle(key, table ?: @"Localizable", bundle, comment)
#endif
