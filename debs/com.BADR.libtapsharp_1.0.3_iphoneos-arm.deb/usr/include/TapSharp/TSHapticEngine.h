@interface TSHapticEngine : NSObject
@property (nonatomic, retain) UIImpactFeedbackGenerator *impact;
+ (instancetype)sharedInstance;
-(void)prepare;
-(void)fire;
@end
