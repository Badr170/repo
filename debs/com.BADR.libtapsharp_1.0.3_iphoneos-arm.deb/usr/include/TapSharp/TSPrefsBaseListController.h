#import <Preferences/PSListController.h>

@interface TSPrefsBaseListController : PSListController
-(void)respringDevice;
-(void)respringDevice:(NSString *)title message:(NSString *)message;
@end
