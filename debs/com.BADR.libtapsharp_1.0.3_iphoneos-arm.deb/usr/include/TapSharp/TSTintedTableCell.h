#import <Preferences/PSTableCell.h>

@interface TSTintedTableCell : PSTableCell
@end
