/*
	Script for setting the viewport and location of the widget.
	
	Author:
		Cole Schaefer (@coleschaefer_)

*/

(function() {
	'use strict';
	let scale;
	switch (window.innerWidth) {
		case 320: scale = 0.850; break;
		case 414: scale = 1.104; break;
		case 425: scale = 1.133; break;
		case 432: scale = 1.152; break;
		default:  scale = 1.000; break;
	}
	document.querySelector("meta[name=viewport]").setAttribute('content', 'width=device-width, initial-scale=' + scale + ', maximum-scale=' + scale + ', user-scalable=0');
}());

(function() {
	'use strict';
	document.getElementById("widget").style.top = (window.innerHeight === 812) ? '60px' : '0';
}());
console.log('[HSWB] تمت تهيئة وظائف إطار العرض!');