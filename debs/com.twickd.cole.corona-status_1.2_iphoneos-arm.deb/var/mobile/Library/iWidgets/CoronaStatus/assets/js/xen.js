function mainUpdate(type) {
	document.getElementById('left_top').addEventListener('touchstart', () => {
		$('#covid_title').text("..جار التحميل");
		$('#covid_cases').text("..جار التحميل");
		$('#covid_deaths').text("..جار التحميل");
		$('#covid_recoveries').text("..جار التحميل");
		init_main();
	});
}
console.log('[HSWB] XenInfx تمت تهيئة وظائف!');
